import openai

def chat_with_openai():
    openai.api_key = "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"

    print("Welcome to the OpenAI Chatbot! Type 'quit' to exit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "quit":
            print("Exiting the chat. Goodbye!")
            break
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": user_input}],
            )
            bot_response = response.choices[0].message['content'].strip()
            print(f"AI: {bot_response}")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    chat_with_openai()
